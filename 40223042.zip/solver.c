//Shanli Samienezhad 40223042
#include <stdio.h>
#include <math.h>

void solver(double, double , double , double * , double *);

int main()
{
    double a , b , c;
    
    printf("First input(a)(x^2):\n");
    scanf("%lf", &a);
    
    printf("Second input(b)(x):\n");
    scanf("%lf", &b);

    printf("Third input(c):\n");
    scanf("%lf", &c);

    while( ( a == 0 ) && ( b == 0 ) )
    {
        printf("Wrong input, a and b cannot be 0 at the same time.\n");
        printf("First input(a)(x^2):\n");
        scanf("%lf", &a);
     
        printf("Second input(b)(x):\n");
        scanf("%lf", &b);

        printf("Third input(c):\n");
        scanf("%lf", &c);
    }

    double x1 , x2;
    double *p1 = &x1 , *p2 = &x2;

    solver(a , b , c , p1 , p2);

    if( !( b * b < 4 * a * c ) )
    {
        if( *p1 == *p2 )
        {
            printf("This equation has one root.\n");
            printf("root = %lf\n", *p1);
        }

        else
        {
            printf("This equation has two roots.\n");
            printf("root 1 = %lf\n", *p1);
            printf("root 2 = %lf\n", *p2);
        }  
    }      
}

void solver(double a , double b , double c , double *x1 , double *x2) 
{
    if( a == 0 )
    {
        *x1 = -c / b;
        *x2 = -c / b;
    }

    else if( b * b < 4 * a * c )
    {
        printf("This equation has no real roots.\n");
    }

    else
    {
        *x1 = ( -b + sqrt( b * b - 4 * a * c ) ) / ( 2 * a );
        *x2 = ( -b - sqrt( b * b - 4 * a * c ) ) / ( 2 * a );
    }
}